
package Controller;

import Model.ListPenjualan;
import Model.Penjualan;
import java.io.IOException;
import java.io.PrintStream;
import java.net.Socket;
import java.util.Scanner;


public class Client {
    public static void main(String[] args) throws IOException {
        String kata = "aku"+" "+"kau"+" "+"dia";
        String[] kata1 = kata.split(" ");
        System.out.println(kata1[1]);

    }
}
