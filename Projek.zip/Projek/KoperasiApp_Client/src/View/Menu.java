/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View;

import Model.ListPenjualan;
import Model.Penjualan;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;

public class Menu extends javax.swing.JFrame {

    //atribut komponen
    Socket s;
    ObjectOutputStream oos;
    ObjectInputStream ois;
    int port = 1342;
    String host = "localhost";
    String hargaTotal = null;

    public Menu() {
        initComponents();
        //constructor menu = class
        try {
            s = new Socket("172.27.41.254", 1342);
            oos = new ObjectOutputStream(s.getOutputStream());
            ois = new ObjectInputStream(s.getInputStream());
        } catch (IOException ex) {
            System.out.println(ex);
        }
    }


    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        cb_Bungkus = new javax.swing.JComboBox<>();
        cb_gorengan = new javax.swing.JComboBox<>();
        cb_botol = new javax.swing.JComboBox<>();
        cb_Kaleng = new javax.swing.JComboBox<>();
        txtTotal = new javax.swing.JTextField();
        btnSubmit = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jTable2);

        jLabel1.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(102, 102, 0));
        jLabel1.setText("JUMLAH TOTAL PEMBELIAN");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(51, 204, 0));
        getContentPane().setLayout(null);

        cb_Bungkus.setBackground(new java.awt.Color(255, 102, 204));
        cb_Bungkus.setFont(new java.awt.Font("Trajan Pro", 1, 14)); // NOI18N
        cb_Bungkus.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Beng - Beng\t\t Rp.3000", "Kacang Garuda\t Rp.2000", "Godok-Godok   \t Rp.1000", "Risol               \t Rp.1000", "Segitiga          \t Rp.2000", "Bakwan          \t Rp.1000", "Sosis\t \t Rp.1500", "Tahu Isi\t\t Rp.1000", "Pisang Goreng \t Rp.1500", "PisangCoklat\t  \t Rp.1500", "UbiCoklat\t   \tRp.1000", "Klepon    \t\t Rp.1500", "Naga Sari  \t   \tRp.1500", "Ombus-ombus    \tRp.2000", "Onde-Onde       \t Rp.1000", "Lupis                  \tRp.2000", "Kue Lapis  \t  \tRp.1500", "Kue Lumpur       \t Rp.2000", "Kue Mangkok      \tRp.2000", "Getuk \t  \tRp.2000", "Putu     \t\tRp.2000", "Lemper  \t\tRp.2500", "Bikang  \t\tRp.3000", "Dadar Gulung   \tRp.1500", "Bugis Ketan     \tRp.1000", "Wajik   \t\tRp.1000", "Bakpao           \tRp.3000", "Paha Ayam     \tRp.1000" }));
        cb_Bungkus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cb_BungkusActionPerformed(evt);
            }
        });
        getContentPane().add(cb_Bungkus);
        cb_Bungkus.setBounds(10, 170, 190, 60);

        cb_gorengan.setBackground(new java.awt.Color(102, 255, 51));
        cb_gorengan.setFont(new java.awt.Font("Trajan Pro", 1, 14)); // NOI18N
        cb_gorengan.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Risol\t\tRp.2000", "bakso\t\tRp.1000", "Piscok   \t\tRp.2000", "Tahu goreng\t \tRp.2000", "Tempe goreng\tRp.1000", "Pisang goreng\tRp.2000", " " }));
        cb_gorengan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cb_gorenganActionPerformed(evt);
            }
        });
        getContentPane().add(cb_gorengan);
        cb_gorengan.setBounds(210, 170, 190, 60);

        cb_botol.setBackground(new java.awt.Color(0, 204, 153));
        cb_botol.setFont(new java.awt.Font("Trajan Pro", 1, 14)); // NOI18N
        cb_botol.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Sosro\tRp.3000", "Fruite tea\tRp.2500", "Pop Ice\tRp.5000", "Bubble\tRp.4000", "Fanta\t Rp.7000", "Sprite \tRp.5000", "Coca-cola\t Rp.6000", "Capucino\t Rp.5000", " " }));
        getContentPane().add(cb_botol);
        cb_botol.setBounds(410, 170, 170, 60);

        cb_Kaleng.setBackground(new java.awt.Color(51, 255, 255));
        cb_Kaleng.setFont(new java.awt.Font("Trajan Pro", 1, 14)); // NOI18N
        cb_Kaleng.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Kratindeng\t\tRp.6000", "Pocari sweet\t\tRp.3000", "Nescafe \t\tRp.3000", "Sprite \t\tRp.3000", "BearBrand \t\tRp.5000", "M150 \t\tRp.4000" }));
        cb_Kaleng.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cb_KalengActionPerformed(evt);
            }
        });
        getContentPane().add(cb_Kaleng);
        cb_Kaleng.setBounds(590, 170, 190, 60);

        txtTotal.setBackground(new java.awt.Color(255, 204, 153));
        txtTotal.setCaretColor(new java.awt.Color(102, 102, 255));
        txtTotal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTotalActionPerformed(evt);
            }
        });
        getContentPane().add(txtTotal);
        txtTotal.setBounds(500, 330, 256, 50);

        btnSubmit.setBackground(new java.awt.Color(204, 255, 255));
        btnSubmit.setFont(new java.awt.Font("Wide Latin", 1, 14)); // NOI18N
        btnSubmit.setForeground(new java.awt.Color(255, 0, 0));
        btnSubmit.setText("SUBMIT");
        btnSubmit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSubmitActionPerformed(evt);
            }
        });
        getContentPane().add(btnSubmit);
        btnSubmit.setBounds(560, 270, 190, 40);

        jLabel2.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(153, 0, 153));
        jLabel2.setText("SELAMAT  DATANG DI JUAL BELI ONLINE  ");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(200, 20, 550, 40);

        jLabel3.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 1, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(102, 255, 153));
        jLabel3.setText("Menu Minuman");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(520, 100, 160, 26);

        jLabel4.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 1, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(51, 255, 153));
        jLabel4.setText("Menu Makanan");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(140, 100, 180, 26);

        jLabel5.setBackground(new java.awt.Color(153, 204, 255));
        jLabel5.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 1, 24)); // NOI18N
        jLabel5.setText("Bungkus");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(70, 131, 90, 26);

        jLabel6.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 1, 24)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(51, 51, 51));
        jLabel6.setText("Gorengan");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(260, 130, 110, 26);

        jLabel7.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 1, 24)); // NOI18N
        jLabel7.setText("Botol");
        getContentPane().add(jLabel7);
        jLabel7.setBounds(460, 130, 80, 26);

        jLabel8.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 1, 24)); // NOI18N
        jLabel8.setText("Kaleng");
        getContentPane().add(jLabel8);
        jLabel8.setBounds(650, 130, 80, 26);

        jTextField1.setBackground(new java.awt.Color(255, 204, 153));
        jTextField1.setFont(new java.awt.Font("Stencil Std", 1, 18)); // NOI18N
        jTextField1.setForeground(new java.awt.Color(51, 51, 0));
        jTextField1.setText("Total Pembayaran ");
        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField1);
        jTextField1.setBounds(22, 334, 278, 50);

        jLabel9.setBackground(new java.awt.Color(255, 255, 255));
        jLabel9.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 1, 24)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(153, 0, 153));
        jLabel9.setText("INSTITUT TEKNOLOGI DEL");
        getContentPane().add(jLabel9);
        jLabel9.setBounds(280, 60, 281, 21);

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/View/IMG_20180317_174735.jpg"))); // NOI18N
        getContentPane().add(jLabel10);
        jLabel10.setBounds(0, 0, 790, 410);
        getContentPane().add(jLabel11);
        jLabel11.setBounds(0, 0, 780, 410);

        jLabel12.setText("jLabel12");
        getContentPane().add(jLabel12);
        jLabel12.setBounds(10, 0, 780, 410);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cb_BungkusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cb_BungkusActionPerformed
    

    }//GEN-LAST:event_cb_BungkusActionPerformed

    private void cb_gorenganActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cb_gorenganActionPerformed
      
    }//GEN-LAST:event_cb_gorenganActionPerformed

    private void cb_KalengActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cb_KalengActionPerformed
       
    }//GEN-LAST:event_cb_KalengActionPerformed

    private void btnSubmitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSubmitActionPerformed
        // TODO add your handling code here:
        //mengambil data dari combo button
        String bungkus = cb_Bungkus.getSelectedItem().toString();
        String gorengan = cb_gorengan.getSelectedItem().toString();
        String botol = cb_botol.getSelectedItem().toString();
        String kaleng = cb_Kaleng.getSelectedItem().toString();

        try { //dikumpulkan dari yang sudah diambil dari atas
            
            String all = bungkus + "\n" + gorengan + "\n" + botol + "\n" + kaleng;
            oos.writeObject(all); //networkingnya  untuk transaksi
            System.out.println(bungkus);
            System.out.println(gorengan);
            System.out.println(botol);
            System.out.println(kaleng);
            String message = (String) ois.readObject(); //kasih balasan untuk penjumlahan
            hargaTotal = message;
            txtTotal.setText(message);
            System.out.println(message);

        } catch (IOException ex) {
            Logger.getLogger(Menu.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Menu.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnSubmitActionPerformed

    private void txtTotalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTotalActionPerformed

    }//GEN-LAST:event_txtTotalActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed

    }//GEN-LAST:event_jTextField1ActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(() -> {
            new Menu().setVisible(true);
        });
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnSubmit;
    private javax.swing.JComboBox<String> cb_Bungkus;
    private javax.swing.JComboBox<String> cb_Kaleng;
    private javax.swing.JComboBox<String> cb_botol;
    private javax.swing.JComboBox<String> cb_gorengan;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField txtTotal;
    // End of variables declaration//GEN-END:variables
}
