package Model;

import java.util.ArrayList;

public class ListPenjualan {
    
    public static ArrayList<Penjualan> listPenjualan = new ArrayList<>();
    
    public void addToPenjualan(String bungkus, 
                               String gorengan, 
                               String botol, 
                               String kaleng)
    {
        
        Penjualan newPenjualan = new Penjualan(bungkus, gorengan, botol, kaleng);
        listPenjualan.add(newPenjualan);
    }
    
    public ArrayList<Penjualan> getListPenjualan(){
        return listPenjualan;
    }
}
