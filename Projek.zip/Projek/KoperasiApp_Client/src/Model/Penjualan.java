package Model;

public class Penjualan {
    private String bungkus,goreng, botol, kaleng;

    public Penjualan(String bungkus, String goreng, String botol, String kaleng) {
        this.bungkus = bungkus;
        this.goreng = goreng;
        this.botol = botol;
        this.kaleng = kaleng;
    }

    public String getBungkus() {
        return bungkus;
    }

    public void setBungkus(String bungkus) {
        this.bungkus = bungkus;
    }

    public String getGoreng() {
        return goreng;
    }

    public void setGoreng(String goreng) {
        this.goreng = goreng;
    }

    public String getBotol() {
        return botol;
    }

    public void setBotol(String botol) {
        this.botol = botol;
    }

    public String getKaleng() {
        return kaleng;
    }

    public void setKaleng(String kaleng) {
        this.kaleng = kaleng;
    }

    String getNoTransaksi() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }
}
