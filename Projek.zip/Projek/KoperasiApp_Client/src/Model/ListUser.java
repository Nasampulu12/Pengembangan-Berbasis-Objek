package Model;

import java.util.ArrayList;

public class ListUser {
     public static ArrayList<User> listUser = new ArrayList<>();
    
    public void addToUserList(){
        User newUser = new User("user", "user", "1");
        listUser.add(newUser);
    }
    
    public boolean isAuth(String username, String password){
        boolean isAuth = false;
        for(int i = 0; i < listUser.size(); i++){
            return username.equals(listUser.get(i).getUsername()) && password.equals(listUser.get(i).getPassword());
        }
        return false;
    }
  
}

