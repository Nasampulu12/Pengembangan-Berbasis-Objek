package Model;

public class User {
   private String username, password;

    public User(String username, String password, String saldo) {
        this.username = username;
        this.password = password;   
    }

    public User() {
    }

    User(String user, String user0, String sarah, String barasa, String string) {
        System.out.println("");
    }

    User(String user, String user0) {
        System.out.println("");
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
