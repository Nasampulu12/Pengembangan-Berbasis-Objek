/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.ArrayList;

/**
 *
 * @author itd-stu
 */
public class ListUser {
     public static ArrayList<User> listUser = new ArrayList<>();
    
    public void addToUserList(){
        User newUser = new User("admin", "admin", "1");
        listUser.add(newUser);
    }
    
    public boolean isAuth(String username, String password){
        boolean isAuth = false;
        for(int i = 0; i < listUser.size(); i++){
            return username.equals(listUser.get(i).getUsername()) && password.equals(listUser.get(i).getPassword());
        }
        return false;
    }
    
    public void exportToFile(){
        
    }
    
}

