/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.ArrayList;

/**
 *
 * @author itd-stu
 */
public class ListPenjualan {

    public static ArrayList<Penjualan> listPenjualan = new ArrayList<Penjualan>();

    public void addToPenjualan(String bungkus, String gorengan, String botol, String kaleng) {
        Penjualan newPenjualan = new Penjualan(bungkus, gorengan, botol, kaleng);
        listPenjualan.add(newPenjualan);
    }

    public ArrayList<Penjualan> getListPenjualan() {
        return listPenjualan;
    }

//    public boolean deletePenjualan(String noTransaksi){
//        for(int i = 0; i < listPenjualan.size(); i++){
//            if(noTransaksi == listPenjualan.get(i).getNoTransaksi()){
//                listPenjualan.remove(i);
//                return true;
//            }else {
//                return false;
//            }
//        }
//        return false;
//    }
//    
//    public boolean editPenjualan(String noTransaksi, String noPlg, String namaToko){
//        for(int i = 0; i < listPenjualan.size(); i++){
//            if(noTransaksi == listPenjualan.get(i).getNoTransaksi()){
//                listPenjualan.get(i).setToko(namaToko);
//                listPenjualan.get(i).setNoPelanggan(noPlg);      //
//                return true;
//            }else {
//                return false;
//            }
//        }
//        return false;
//    }
}

