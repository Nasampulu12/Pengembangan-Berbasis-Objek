/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View;

import Model.ListPenjualan;
import Model.Penjualan;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;

public class Menu extends javax.swing.JFrame {

    ServerSocket sl;
    Socket s;
    ObjectInputStream ois;
    ObjectOutputStream oos;

    public Menu() {
        try {

            sl = new ServerSocket(1342);
            s = sl.accept();
            System.out.println("cek");
            ois = new ObjectInputStream(s.getInputStream());
            oos = new ObjectOutputStream(s.getOutputStream());

        } catch (IOException ex) {
            System.out.println("error");
        }
        initComponents();
    }

    public String totalHarga = null;
    FileOutputStream fileout = null;

    public void tampilkandata() {
        try {
            String log = "";
            fileout = new FileOutputStream("log.txt");
            DefaultTableModel tbjual = new DefaultTableModel();
//        tbjual.addTableModelListener(tabelTransaksi);
            tbjual.addColumn("bungkus");
            tbjual.addColumn("gorengan");
            tbjual.addColumn("botol");
            tbjual.addColumn("kaleng");
            tbjual.setRowCount(0);

            for (int i = 0; i < ListPenjualan.listPenjualan.size(); i++) {//membaca isi dari list penjualan
                tbjual.addRow(new Object[]{
                    ListPenjualan.listPenjualan.get(i).getBungkus(),
                    ListPenjualan.listPenjualan.get(i).getGoreng(),
                    ListPenjualan.listPenjualan.get(i).getBotol(),
                    ListPenjualan.listPenjualan.get(i).getKaleng()
                });

                log = ListPenjualan.listPenjualan.get(i).getBungkus() + "|"
                        + ListPenjualan.listPenjualan.get(i).getGoreng() + "|"
                        + ListPenjualan.listPenjualan.get(i).getBotol() + "|"
                        + ListPenjualan.listPenjualan.get(i).getKaleng() + "\r\n";
                fileout.write(log.getBytes());
            }
            System.out.println(log);
            tabelTransaksi.setModel(tbjual);
            Harga.setText(totalHarga); //menampilkan harga
// <editor-fold defaultstate="collapsed" desc="Generated Code">
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Menu.class.getName()).log(Level.SEVERE, null, ex);

        } catch (IOException ex) {
            Logger.getLogger(Menu.class.getName()).log(Level.SEVERE, null, ex);

        } finally {
            if (fileout != null) {

                try {
                    fileout.close(); //telah selesai penulisan file
                } catch (IOException ex) {
                    System.out.println(ex);
                }
            }
        }

    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        cb_Bungkus = new javax.swing.JComboBox<>();
        cb_gorengan = new javax.swing.JComboBox<>();
        cb_botol = new javax.swing.JComboBox<>();
        cb_Kaleng = new javax.swing.JComboBox<>();
        Harga = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        btnSubmit = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tabelTransaksi = new javax.swing.JTable();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jTable2);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(51, 204, 0));
        getContentPane().setLayout(null);

        cb_Bungkus.setForeground(new java.awt.Color(255, 51, 102));
        cb_Bungkus.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Beng - Beng\tRp.3000", "Kacang Garuda\t Rp.2000", "Godok-Godok    Rp.1000", "Risol                Rp.1000", "Segitiga           Rp.2000", "Bakwan            Rp.1000", "Sosis\t Rp.1500", "Tahu Isi\t Rp.1000", "Pisang Goreng    Rp.1500", "PisangCoklat\t   Rp.1500", "UbiCoklat\t   Rp.100", "Klepon                Rp.1500", "Naga Sari  \t   Rp.1500", "Ombus-ombus    Rp.2000", "Onde-Onde \t\tRp.1000", "Lupis\t\t Rp.2000", "Kue Lapis \t\tRp.1500", "Kue Lumpur\t\tRp.2000", "Kue Mangkok \t\t Rp.2000", "Getuk\t\tRp.2000", "Putu  \t\tRp.2000", "Lemper\t\tRp.2500", "Bikang \t\tRp.3000", "Dadar Gulung \t\tRp.1500", "Bugis Ketan \t\tRp.1000", "Wajik   \t\tRp.1000", "Bakpao          \t\tRp.3000", "Paha Ayam     \t\tRp.1000" }));
        cb_Bungkus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cb_BungkusActionPerformed(evt);
            }
        });
        getContentPane().add(cb_Bungkus);
        cb_Bungkus.setBounds(38, 170, 176, 22);

        cb_gorengan.setBackground(new java.awt.Color(102, 102, 255));
        cb_gorengan.setForeground(new java.awt.Color(255, 0, 102));
        cb_gorengan.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Risol\t\tRp.2000", "bakso\t\tRp.1000", "Godok Godok\t\tRp.2000" }));
        cb_gorengan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cb_gorenganActionPerformed(evt);
            }
        });
        getContentPane().add(cb_gorengan);
        cb_gorengan.setBounds(310, 170, 170, 22);

        cb_botol.setForeground(new java.awt.Color(255, 51, 51));
        cb_botol.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Sosro\t\tRp.3000", "Fruite tea\t\tRp.2500", "Pop Ice\t\tRp.5000", "Bubble\t\tRp.4000", "Fanta\t\t Rp.7000", "Sprite \t\tRp.5000", "Coca-cola \t\tRp.6000", "Capucino \t\tRp.5000", " " }));
        getContentPane().add(cb_botol);
        cb_botol.setBounds(540, 170, 150, 22);

        cb_Kaleng.setForeground(new java.awt.Color(255, 0, 51));
        cb_Kaleng.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Kratindeng\t\tRp.6000", "Pocari sweet\t\tRp.3000", "Nescafe\t\t Rp.3000", "Sprite\t\t Rp.3000", "BearBrand\t\t Rp.5000", "M150 \t\tRp.4000" }));
        cb_Kaleng.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cb_KalengActionPerformed(evt);
            }
        });
        getContentPane().add(cb_Kaleng);
        cb_Kaleng.setBounds(750, 170, 147, 22);

        Harga.setBackground(new java.awt.Color(204, 204, 255));
        Harga.setFont(new java.awt.Font("Wide Latin", 1, 18)); // NOI18N
        Harga.setCaretColor(new java.awt.Color(255, 51, 0));
        Harga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                HargaActionPerformed(evt);
            }
        });
        getContentPane().add(Harga);
        Harga.setBounds(650, 430, 240, 40);

        jLabel1.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(102, 102, 0));
        jLabel1.setText("JUMLAH PEMBAYARAN");
        jLabel1.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                jLabel1AncestorAdded(evt);
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        getContentPane().add(jLabel1);
        jLabel1.setBounds(20, 430, 259, 30);

        btnSubmit.setBackground(new java.awt.Color(255, 0, 0));
        btnSubmit.setFont(new java.awt.Font("Wide Latin", 1, 14)); // NOI18N
        btnSubmit.setForeground(new java.awt.Color(0, 0, 153));
        btnSubmit.setText("ACCEPT");
        btnSubmit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSubmitActionPerformed(evt);
            }
        });
        getContentPane().add(btnSubmit);
        btnSubmit.setBounds(370, 400, 149, 23);

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(jLabel2.getFont().deriveFont(jLabel2.getFont().getStyle() | java.awt.Font.BOLD, jLabel2.getFont().getSize()+16));
        jLabel2.setForeground(new java.awt.Color(0, 51, 51));
        jLabel2.setText("SELAMAT  DATANG  DI JUAL BELI ONLINE ");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(160, 0, 690, 60);

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 0));
        jLabel3.setText("Menu Minuman");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(660, 90, 180, 30);

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 0, 51));
        jLabel4.setText("Menu Makanan");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(90, 100, 150, 22);

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 255));
        jLabel5.setText("Makanan Berbungkus");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(50, 140, 160, 17);

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 153));
        jLabel6.setText("Gorengan");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(360, 140, 90, 17);

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(51, 255, 0));
        jLabel7.setText("Minuman Botol");
        getContentPane().add(jLabel7);
        jLabel7.setBounds(550, 140, 140, 20);

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(51, 255, 51));
        jLabel8.setText("Minuman Kaleng");
        getContentPane().add(jLabel8);
        jLabel8.setBounds(740, 140, 160, 20);

        tabelTransaksi.setBackground(new java.awt.Color(255, 204, 204));
        tabelTransaksi.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tabelTransaksi.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentHidden(java.awt.event.ComponentEvent evt) {
                tabelTransaksiComponentHidden(evt);
            }
            public void componentMoved(java.awt.event.ComponentEvent evt) {
                tabelTransaksiComponentMoved(evt);
            }
        });
        jScrollPane3.setViewportView(tabelTransaksi);

        getContentPane().add(jScrollPane3);
        jScrollPane3.setBounds(30, 270, 870, 90);
        getContentPane().add(jLabel9);
        jLabel9.setBounds(201, 93, 267, 0);

        jLabel10.setFont(new java.awt.Font("Kristen ITC", 1, 24)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 51, 51));
        jLabel10.setText("     INSTITUT  TEKNOLOGI  DEL");
        getContentPane().add(jLabel10);
        jLabel10.setBounds(210, 60, 460, 30);

        jLabel11.setIcon(new javax.swing.ImageIcon("C:\\Users\\ITD-STU\\Desktop\\Pictures\\BG\\freepik.com_.jpg")); // NOI18N
        jLabel11.setLabelFor(getMostRecentFocusOwner());
        jLabel11.setText("jLabel11");
        jLabel11.setAlignmentY(0.0F);
        jLabel11.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        getContentPane().add(jLabel11);
        jLabel11.setBounds(0, 0, 920, 500);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cb_gorenganActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cb_gorenganActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cb_gorenganActionPerformed

    private void cb_KalengActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cb_KalengActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cb_KalengActionPerformed

    private void btnSubmitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSubmitActionPerformed
        String data = null;
        String[] makanan;
        String bungkus = null;//tidak dapat mengoperasikan variabel yang tidak ada
        String gorengan = null;
        String botol = null;
        String kaleng = null;
        String harga1 = null;
        String harga2 = null;
        String harga3 = null;
        String harga4 = null;
        try {
            data = (String) ois.readObject();//membaca apa yang dimasukkan proses pertukarannya
            makanan = data.split("\n");
            bungkus = makanan[0];
            gorengan = makanan[1];
            botol = makanan[2];
            kaleng = makanan[3];
            harga1 = bungkus.split("Rp.")[1];
            harga2 = gorengan.split("Rp.")[1];
            harga3 = botol.split("Rp.")[1];
            harga4 = kaleng.split("Rp.")[1];
            int hargaTotal = Integer.parseInt(harga1) + Integer.parseInt(harga2) + Integer.parseInt(harga3) + Integer.parseInt(harga4);
            totalHarga = "" + hargaTotal;
            oos.writeObject("" + hargaTotal);

        } catch (IOException ex) {

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Menu.class.getName()).log(Level.SEVERE, null, ex);
        }
        Penjualan newPenjualan = new Penjualan(bungkus, gorengan, botol, kaleng);
        ListPenjualan.listPenjualan.add(newPenjualan);

        this.tampilkandata();
    }//GEN-LAST:event_btnSubmitActionPerformed

    private void tabelTransaksiComponentHidden(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_tabelTransaksiComponentHidden
        // TODO add your handling code here:
    }//GEN-LAST:event_tabelTransaksiComponentHidden

    private void tabelTransaksiComponentMoved(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_tabelTransaksiComponentMoved
        // TODO add your handling code here:
    }//GEN-LAST:event_tabelTransaksiComponentMoved

    private void HargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_HargaActionPerformed
        // TODO add your handling code here:


    }//GEN-LAST:event_HargaActionPerformed

    private void jLabel1AncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_jLabel1AncestorAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel1AncestorAdded

    private void cb_BungkusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cb_BungkusActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cb_BungkusActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Menu().setVisible(true);
            }
        });
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Harga;
    private javax.swing.JButton btnSubmit;
    private javax.swing.JComboBox<String> cb_Bungkus;
    private javax.swing.JComboBox<String> cb_Kaleng;
    private javax.swing.JComboBox<String> cb_botol;
    private javax.swing.JComboBox<String> cb_gorengan;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable tabelTransaksi;
    // End of variables declaration//GEN-END:variables
}
